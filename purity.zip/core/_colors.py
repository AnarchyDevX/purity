class Colors:
    def __init__(self) -> None:
        self.RED = "[31m"
        self.GREEN = "[32m"
        self.YELLOW = "[33m"
        self.BLUE = "[34m"
        self.MAGENTA = "[35m"
        self.CYAN = "[36m"
        self.WHITE = "[37m"
        self.RESET = "[0m" 