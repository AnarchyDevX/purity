import discord
from discord import app_commands
from discord.ext import commands
from functions.functions import *
from core.embedBuilder import embedBuilder

class antiRoleCOnfig(commands.Cog):
    def __init__(self, bot) -> None:
        self.bot: commands.Bot = bot

    @app_commands.command(name="antiraid-antirole", description="Configurer l'antichannel")
    @app_commands.choices(
        option=[
            app_commands.Choice(name="all", value="all"),
            app_commands.Choice(name="crée", value="create"),
            app_commands.Choice(name="modifié", value="edit"),
            app_commands.Choice(name="supprimé", value="delete")
        ],
        status=[
            app_commands.Choice(name="on", value="True"),
            app_commands.Choice(name="off", value="False")
        ]
    )
    async def antiRoleCOnfig(self, interaction: discord.Interaction, option: str, status: str):
        if not await check_perms(interaction, 2): return

        status = True if status == "True" else False

        guildJSON = load_json_file(f"./configs/{interaction.guild.id}.json")
        if option == "all":
            guildJSON['antiraid']["roles"]['create'] = status
            guildJSON['antiraid']["roles"]['edit'] = status
            guildJSON['antiraid']["roles"]['edit'] = status

        else:
            guildJSON['antiraid']["roles"][option] = status

        json.dump(guildJSON, open(f'./configs/{interaction.guild.id}.json', 'w'), indent=4)
        title = None
        if option == "all":
            title = "all"
        elif option == "create":
            title = "crée"
        elif option == "edit":
            title = "modifié"
        elif option == "delete":
            title == "supprimé"

        embed: embedBuilder = embedBuilder(
            title=f"`🛡️`・Antirole {title} {'activé' if status == True else 'désactivé'}",
            description=f"*L'antirole {title} à bien été {'activé' if status == True else 'désactivé'}*",
            color=embed_color(),
            footer=footer()
        )
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(antiRoleCOnfig(bot))