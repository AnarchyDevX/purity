"# purity" 
