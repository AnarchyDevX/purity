import discord
from discord.ui import TextInput, Modal
from functions.functions import *
from core.embedBuilder import embedBuilder

class badwordAddModal(Modal):
    def __init__(self, userId):
        self.userId = userId
        super().__init__(
            title="Ajout d'un badwords"
        )
        first = TextInput(
            label="Ajout du badword",
            style=discord.TextStyle.short,
            min_length=1,
            max_length=300,
            required=True,
            placeholder="Entrez votre badword ici..."
        )
        self.add_item(first)

    async def on_submit(self, interaction: discord.Interaction):
        from views.badwords.badwordAdd import badwordsAddButton
        from views.badwords.badwordRemove import badwordsRemoveButton

        mot = self.children[0].value
        guildJSON = load_json_file(f"./configs/{interaction.guild.id}.json")
        badwordsList = guildJSON['badwords']
        if mot in badwordsList:
            return await err_embed(
                interaction,
                title="Badword déja présent",
                description=f"Le mot `{mot}` est déja présent dans la liste des badwords."
            )
        badwordsList.append(mot)
        json.dump(guildJSON, open(f"./configs/{interaction.guild.id}.json", 'w'), indent=4)
        badwords = ", ".join(guildJSON['badwords'])
        embed: embedBuilder = embedBuilder(
            title="`🧪`・Badwords",
            description=(
                f"> `🪄`・**Total:** `{len(guildJSON['badwords'])}`\n"
                f"> `📜`・**Liste:** ```{badwords}```\n"
            ),
            color=embed_color(),
            footer=footer()
        )
        view = discord.ui.View(timeout=None)
        view.add_item(badwordsAddButton(self.userId))
        view.add_item(badwordsRemoveButton(self.userId))
        await interaction.response.edit_message(embed=embed, view=view)